import React from "react";
import "./footer.scss";

export const Footer = () => {
  return (
    <>
      <div>
        <footer id="footer-we">
          <p>©2023 JMR Airlines</p>
        </footer>
      </div>
    </>
  );
};
